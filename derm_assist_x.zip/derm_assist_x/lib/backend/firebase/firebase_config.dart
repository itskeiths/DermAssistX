import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAahdk_UcOiH5sKTtfpk7Ap4pVtjqkrt84",
            authDomain: "dermassistx-bc6fb.firebaseapp.com",
            projectId: "dermassistx-bc6fb",
            storageBucket: "dermassistx-bc6fb.appspot.com",
            messagingSenderId: "132812761933",
            appId: "1:132812761933:web:120a94eb2743a6dec26504",
            measurementId: "G-YYK98Y1J85"));
  } else {
    await Firebase.initializeApp();
  }
}
