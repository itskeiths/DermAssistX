import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/empty_list/empty_list_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'profile_page_model.dart';
export 'profile_page_model.dart';

class ProfilePageWidget extends StatefulWidget {
  const ProfilePageWidget({
    Key? key,
    this.userProfile,
  }) : super(key: key);

  final DocumentReference? userProfile;

  @override
  _ProfilePageWidgetState createState() => _ProfilePageWidgetState();
}

class _ProfilePageWidgetState extends State<ProfilePageWidget>
    with TickerProviderStateMixin {
  late ProfilePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  var hasContainerTriggered1 = false;
  var hasContainerTriggered2 = false;
  final animationsMap = {
    'containerOnActionTriggerAnimation1': AnimationInfo(
      trigger: AnimationTrigger.onActionTrigger,
      applyInitialState: false,
      effects: [
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 350.ms,
          begin: Offset(40.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'containerOnActionTriggerAnimation2': AnimationInfo(
      trigger: AnimationTrigger.onActionTrigger,
      applyInitialState: false,
      effects: [
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 350.ms,
          begin: Offset(-40.0, 0.0),
          end: Offset(0.0, 0.0),
        ),
      ],
    ),
    'listViewOnPageLoadAnimation': AnimationInfo(
      trigger: AnimationTrigger.onPageLoad,
      effects: [
        FadeEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: 0.0,
          end: 1.0,
        ),
        MoveEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: Offset(-0.0, 51.0),
          end: Offset(0.0, 0.0),
        ),
        ScaleEffect(
          curve: Curves.easeInOut,
          delay: 0.ms,
          duration: 600.ms,
          begin: 1.0,
          end: 1.0,
        ),
      ],
    ),
  };

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ProfilePageModel());

    setupAnimations(
      animationsMap.values.where((anim) =>
          anim.trigger == AnimationTrigger.onActionTrigger ||
          !anim.applyInitialState),
      this,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<UsersRecord>(
      stream: UsersRecord.getDocument(currentUserReference!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 40.0,
              height: 40.0,
              child: SpinKitPumpingHeart(
                color: FlutterFlowTheme.of(context).primary,
                size: 40.0,
              ),
            ),
          );
        }
        final profilePageUsersRecord = snapshot.data!;
        return Scaffold(
          key: scaffoldKey,
          backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
          body: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width * 1.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 0.0, 0.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 60.0, 0.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Card(
                                    clipBehavior: Clip.antiAliasWithSaveLayer,
                                    color: FlutterFlowTheme.of(context).primary,
                                    elevation: 2.0,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(40.0),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          2.0, 2.0, 2.0, 2.0),
                                      child: Container(
                                        width: 60.0,
                                        height: 60.0,
                                        clipBehavior: Clip.antiAlias,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.network(
                                          'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAABv1BMVEX///9msy/4upGFFyLsYz/hlF72rHuHACFkuTBlti/+wZZltS9kuDBcrxn4vJNZrhB8ABT/upbrXTlFmjV9ABmGCyJisSbrWS99ABb7upPrVipmsS/f7tfwr4lZsyW52qal0IxyhirrVVb5/PeVyHfL475zgCp4bCh6YCdpqC7Si291dynCd2EAADA3mC9ulSznNDf0oHnC3rOy1p1/vld+SSXq9OSLxGhwjCuoU0ixYVGJHiaaPjnW6cvlmG7vq33suYn1taf98O10uUVroS18VSaAOySCLCOBNSR7XCeRLzDdmXnId1kylB5+SyXJsHjmHyP51dXwgG7lmWHwg17zo5LudFDykmz4y8GdzIF4aCihSkLJf2fwpHbWhmPLmHx9XFYoFTgSADfiqYVQN0eWb2K9a1IAAB5+eYqDnIM4iC2Il4xPUGqxgGhkjWSgo6IAABAAAChdp07KydCvkImDuHZ3Yma30K/96d/818GXw5P5xqbTs341KD2bbVzHYDLVe1HsZFXpRT7xmZrsa2zrWVnwiortaWq1oU3It3ChtVeHtEaztmOrtl3CQzCiMCqUEA/Xvr+bT1WtJRLxlYDI7fWVAAAQpklEQVR4nO2di18TVxbHkwnkBZkEnDxheIOCUQtYNASJBsQatBbkKQZxrWy32+5uX1tc3Rax1gVst7vLH7z3ziTzyjzOvTNJYHd+n09bSTTm23PuOeee+xiPx5UrV65cuXLlypUrV65cuXLlypUrV2dJg1NTN4aHJ3qxJoaHb0xNDTb7Kzmlwe6JyaG5SDQajSiFf746NDnRfaZBB7t7h+YQSSLh1VUikUCkc0O93c3+plTqnrwaQXD6bGpQ9PuunjHKweGhSNTIckaUic3hs+Kxw9dgtquljAwNN/vLW6t7kw5PguybajaCqSbmovR4Fcjo1VNryMG+SMQmXsWQicnTOCKnNm2bT1Yk2nfaGAed5MNKnC7GwT6H+UTGyWZzSeq1ET3NFElMNBtNUPecI/FFV9G55ucONADrxucVhmOTAYeJHLQthNVGxBjx3mgm4BDUgG2h9mBwdP56/8hI/5WuIBFkE83Y7YUZMBRsnx+5sBAPVHV7PkiCGGnWaJwEGTAU7Oq/7QsE4j5Z8cCjdhLERLQZQXXwGiSEtoeuf6imExVY8JJ56lDDAacgHhocPR/XwRPMeIcEEJlxrsElzg2AhwZH7xrgCYgLQaK4mog0tAvQaw0Y6rpgwocd9fbFiziutkMpow2cVfVZAwZH4qZ8QrzB+uj8fDAERGxYoTpkGWPaRxcCFnwK0DsjIRhjozKjdRAN9ps7aI3D5vthRUBk85QAXgAbUGJcGAVlyEgDsoYlYJsX7qGy4oF+UJ1Tf0RrwK47RB4qm/ERDLHOjmoZZNpG83SACPFjmKP21ROwz9qC1IAYEWTFaG/9AK0TfRuli1YQ78IQ65b6rUu14Id2ABHiRRhinQq4KWvARxRRVI14BZT7E3Upwwct/97QdbuASBBANNOoB+E1y+nSqD0XFRSHDcV6pMVJ61JmgZCwpPdi4AqofnN+1t9tOQhD/aQ+mtN99SNYDyfqdO/G+q/sIvVR7jGna8R+WLBxeCgOWQ7C4AViQj6m+/odWJfK2dpm2DrVjxLH0ZlwXvf1wHXgbNHBrDho3VYL3iY24XR4WtdN4wvAbmqXc4TWPuolNyH3OGzgpoF5WOsm4lhXwzqOeoN3iXNhjGfDOX0jXgD2ix2Lp3PWf1cXeTVTCjMM49NF9AFbU4mrzgD2Wo/C0EVyJ81iQn4mpfMesDp1apYBCDPe4B1SQF+KERTO6ozF+F3wsoYThH3WYabtCrkJp8MVxEUdR81DCSMOzIat50xebztxtvf5mKrCfL6GERpNEaL9edQmYAWmnZgvtshKiCxT0iIGLgIHogMZA2JCcieNZcMMo0Cc0SDGYR0brKhdI4JMeJ7QSdWAWForxsGEdo04CFnnDX5ExMelxrSACFH9ewLzUEK7IxEQSAkrNi6W42sBGV5tROAUSiC0F04hJgS3ZziOS/mm9fhw0lDlxfh5goV+O4AToLX6R9bDkONiXCmXHePDunwYUTXRIAg13oidDTeAihT3ZywdMz89xjNhQzoRUTUU78AJE9foAQGTCqSQqZNysVIWWY41gxPEqvw0Dga0NcWApApv27wZYSy3CMETjKicSwVG4YQJ+oQBM6FJj00/bhoZUTkhBjYVK/+TaQGHQdsqQ4b5nssvAs1Xa0SCdGGjY2Pd5cYy7NCkcgR0ghQjEV6ZIiUoV01B9YxxRRN7HMbhE8vYkOL70k9yOCVKiN4EHSHMSb0h/Z5gDEUYPpsr5Utb07ppkEXvj2VzW7np7LPqXDEruSnBJNhL7aaADhuWfosGAfK5WCzFcUK6xxlDYz0+W4pxWKlYLC9WqopYQ5LykQ37qAiB27d1q1IMGCvlpqent3wIE6fFaRViOBfDr6Zi+S30m3K+LY2bxj8k2oJK1TqFpXv9ySEagzwqQEXxi9kZHzfDq32URxOmrexidajyWTxY5dIN3BYWRZX0J4EbgFV1NzeDrcDlkL1kk7Fh1Y9VK+I4I8Ug8RfsGOebEafDBGUbUoRmse0qkHBEQcjN+u+h71cyjJ0WQgORK/u3OWLCBMWKKaSJKBAqW6Vbfv8s54s9k0yDrPeMr7WfbEf8rvJtLu73+0vEhDT5AjgMEaGc8Ll76OtxlUYhHl1Pdp5eunTpdzvP9OeETz5F71769PkzKSeGSyX0EbscMSHFQAR0ukVCRdGGnNTvnxEbheGd5ztPf//ZHz4/d+7zP37xpQ5ieOezP+F3//zFXz59vvOl+Fouhz5im5wwQt79BmZD1fwXjSFkgDHRR5989dUXRc/9c0hfe755Ukv4bXEKv3v5O883yJIV6uldv+Dp0MXuqigyYhfwo5XdYIFwlq364F+RrwuE9wc9xRrAlx7P98K75zyeb3YquYR9vC0SEmYLikUaYFGqQ+iXw8yeZ0ok9Hhe1Npwz3OjYmHPC8mJF/FHlDnCmsZLEWqggcaMkGFeeL67f/ny/b8VX+pFmhfFry+jd79XveuvEBLVpV6KUAPqQekTqijYBw8evDKcWwjvplUv+SteSjS38FL0o4AVjSUhk0YyAhTe1bxSISSaHwqEpG1TaChVx9LZWkIysYUqIXBDhiTiYArqI9YQbjtDiPIhfH2tSkjaUwSffFUuy4iEBTuE+ANwbRuAZitJhHukwMlCXdPsCoQk3SddQjSHIixpkCJkhJBlw1pCX86vSRfEEj5ghjwdEi8kEhAqKm9fyW93IAofgCbApKGUOCHeAI9D1eyJs0koBhqU8IkawlSEwD5bDaHNUCMOw22aQEPabyMgVM3xd20OROGP54hnFliERQ24aNMsW+T9/rGdMWpAaRiS1mxe4hkidP5b04maLaC5Hm8EYGFc1v/86XPBScmHYR0J1d3EXOHS00uLhnwCIssakS6iP1yYQTYkB6wfoaZfypV/+PsPBtG08OOP+wiP30f/0VcZOQAyYfw2+TBsGKGYEo0AZme3GX5/e39W14goki4+H8vD90E3iFC7BJy/Nzu7q98/ZAX/ZI28lM/Nzt7DH0HjpKSE8Fhau27BcVyMp0gY4WyKwws50HMzWkKybAHPh7prT9w0fHFbJqz+aeKZUxMIfSnDhGEodqy6XZh8XoFFWNPA61KvVwdQz4ho9OGFGPwP+kXtUJRW1gIjFHGGuC6Fzy0M1oBT6v4LG06PL78++OCDDw4OPkH/er0+roGUTeij8dE6zp4M9nirjcguH3zyCSKThX58Pa5ElA7QBCgqNgpC+BzfaNNXTDkS2ZONpTc/YcqKBn5+s/RGGXDlJfwAFR/xHB/epzE8+7ulNGL64A360GJxaWljY2mpiH/902vlb5B2X9KakLRP45kD3+HVbnBcJqbcJ4vc9O2G4uOLbw4GVCaUNgvFyWeGgojXSMH9UpPNl6pA8nbg4O0bwXqe4sbPBwMDywpAedde4CKlCYn7peCet7pRowo2OaUR0wNIBwcD794NHOBfLqsiqfSHwCcttCJeySeYAo8Y7dxT+2n67YBCKsDwljQKaWpukZB03QK89mS2CVpVnrLsicT4Tp0oHldTIUUTsSritSd4ujA7bZFXeiJiHD9ZRjrhVTvdFFtnSXaVakS+VQG8cOE12UHLzYQ1jKJUL8rb9AMjtKOQ5qAePJianT20nmSwjFT1Ee70UhP2ERPC58BB013QNcdjtJKPy9CmQiyKvRjwUGN++NAKUT7yRB9HvXQb2+A2NL+yxQxReaYLeIuSkcgBofvajMs2CdFwLCrP5ZFuL1GLZl8bfCAab2WvIt7Tbz2xvGJqmbcxCCn3JoIHonFRUxG3/1DXhIVdxd78eRuDkPYUItRLLQ9Ycq2trTXrUSxTbm2VByH09LaB6K4BAZ2YwTI9NINUeogQy1pA9NpDaV4Pu47OUJSnZuD9NnPC+C4mRGaUNwQLBkSElRtqAiP2AGn36kP30HrbzU/jc61VFRhWXJ0pVF7YF9wUeMOXmagA4YWbRUKcedgqq1wolOWfBDe1D0h5GAHeNDU/Yhm/pyRU6+Fu3L6L2rmpBrpN2DRdxA35sKB3XpqK/qIa0Dlnq3SRMzYhNuIV+4A2DqxDk77ZYW5u39SGD+3lQUF2rqkB1qZtZuPQzIRI/+ixC2jnHDC0H2U2fzJ1UqxjumUKWVFbD08AEhpfg2XhpNhP7RrR3oVY1ncJYpnMLvIFC8BC+tAeItW0Qhas5WbcUMR9mrIJXxlVOB1HthApz49KgiUMw2CaWmQZ1pCxLO6v6Ti2EVBt3zIEM2K74XFu8WwoU6iNN+WCtEUqPUePSLqoRmlEo8pUXrpAkIqCtFzg1TvAqBEduCgKZESj1RlOtYlP6mWwrGaHW5o5pl1ysg0IC6dGdRt8S0aaLtzYDKQVgS7H0LfhDHxbTcd7GkRnLjGdgDyP5GM9RM6y4a1EfNVGvrfboWdBAVa89a//SBlswzRwVPaY0Iy2KlKlIFtPdJdnYiSA2IyHZGZ07i5hy+v0DdyUYBhWzMgc9cALcSeuFKzK+m/TK9yIhmHVjDePoYyO3pUMePhRe+3mL45mS3u649VxD8hXnb3v2tpP22ubNTHyDYoVxiMAo3N37IrqMo+nbT1d72sHIhWgwHjzF6+Fszp1/6wks3ja1tNz9KAjXXMBOXGgUUKmD497zCAduNZTI6OndyC840O2A2+21I7EnA1CwZAmkPV4iodeBzzUEzo+ZDoqe0nVFwPSbYXWQLKHxwm9MVmfh81oS5tQT9fRKwmP0Vy4RpcsdCCZw6MuLaTjg1CUeqWmLfT+ZkeH5iR23nFCARIFHo231ulRgcoGceiY1eJp7pRzjFCAvDmqQHT8yQ+S5FlG25zuKfvwmBLRXqTRMLLyOr9TMwo9SY8e7bmpf41AOKu4gTzvICGTflWdeNT3oaSV2qbnfYfBF1FGG8qaxkAdR2K4qfdTEDcFxC7jiyAU9+ZR1aXGYoVYXv9nIOInr7W/NyZk5a2G9hOiSh2/hBrzkEeE2GP2RRTRxtGByDA3exr0FMvN6JHRKBQRt+ozEJmO40Y9pnPz0OQ+FiQpKzo8ENOHDXvUqs6VSEqFZ5zP+ViFvUYBejx7ppcKyCd8thwlbCAgQoQROhpqio0ERGW4yTFY+QZLzhk2vPf9ZWP5sF4a3x/gZFWDt/anx9dWGw+I4k259mQBluL+eHuEwsfz4ystycyG9deph/bW1tbHee0JCuWzcWgJ2Qrc+lpLZ2dncqXBQ1Ch1UxnZ8vayniZkY+K5BSzC848cRqhseny+ooA19LS0pm51TQ+pKWWZAv+JphzfbyQDvOqp42UgLG0epaGTRfGK2wYDiu51tAkoSNkRvGr4G/V+au2U8NClOYL45hsTfiMKltL8w0oam8lI32hf/pU4lbW19fHkcoFXqVCAb+K3lxBWJX/OSqyijLLzRuBSm1gV8XSNkx/rX53E9ViSUquLTUbTdKtZFIX0I6SnafAQRVazSR/dRIwmTxdfFirv8Wc4ztl9qvq29RvKQf4OjMtTSphAPrXvwVD2uFLZpZPT3zRU/Hb2H/M4qOl+W6djvxgqqXVzgwNJMJbbXb9AtbSaksmSULZmcysnR08UcWNk05EaY2J5g6ZlpONM+CcOipurK4kM0kjTsSWzHQur55ROknFpVury2vJDFKyKuGHtZPVW0tnHE6l4h6+nEbQ0tLe/xKZK1euXLly5cqVK1euXLly5cqVK1f/H/ovcrqQRvnhQ+MAAAAASUVORK5CYII=',
                                        ),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0.0, 0.0, 16.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: 44.0,
                                          height: 44.0,
                                          decoration: BoxDecoration(
                                            color: FlutterFlowTheme.of(context)
                                                .secondaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(8.0),
                                            border: Border.all(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryBackground,
                                              width: 2.0,
                                            ),
                                          ),
                                          child: FlutterFlowIconButton(
                                            borderColor: Colors.transparent,
                                            borderRadius: 30.0,
                                            buttonSize: 46.0,
                                            icon: Icon(
                                              Icons.edit_outlined,
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .grayLight,
                                              size: 24.0,
                                            ),
                                            onPressed: () async {
                                              context.pushNamed(
                                                'editProfile',
                                                queryParams: {
                                                  'userProfile': serializeParam(
                                                    profilePageUsersRecord
                                                        .reference,
                                                    ParamType.DocumentReference,
                                                  ),
                                                }.withoutNulls,
                                              );
                                            },
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  12.0, 0.0, 0.0, 0.0),
                                          child: Container(
                                            width: 44.0,
                                            height: 44.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              border: Border.all(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryBackground,
                                                width: 2.0,
                                              ),
                                            ),
                                            child: FlutterFlowIconButton(
                                              borderColor: Colors.transparent,
                                              borderRadius: 30.0,
                                              buttonSize: 46.0,
                                              icon: Icon(
                                                Icons.login_rounded,
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondary,
                                                size: 24.0,
                                              ),
                                              onPressed: () async {
                                                GoRouter.of(context)
                                                    .prepareAuthEvent();
                                                await authManager.signOut();
                                                GoRouter.of(context)
                                                    .clearRedirectLocation();

                                                context.goNamedAuth(
                                                    'loginPage', mounted);
                                              },
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 0.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Text(
                                    profilePageUsersRecord.displayName!,
                                    style: FlutterFlowTheme.of(context)
                                        .headlineSmall,
                                  ),
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        4.0, 0.0, 0.0, 0.0),
                                    child: Text(
                                      profilePageUsersRecord.age!.toString(),
                                      style: FlutterFlowTheme.of(context)
                                          .titleMedium,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              children: [
                                Padding(
                                  padding: EdgeInsetsDirectional.fromSTEB(
                                      0.0, 8.0, 0.0, 0.0),
                                  child: Text(
                                    profilePageUsersRecord.email!,
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Outfit',
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 20.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Text(
                                    'Ailments',
                                    textAlign: TextAlign.start,
                                    style:
                                        FlutterFlowTheme.of(context).bodySmall,
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 8.0, 20.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Expanded(
                                    child: AutoSizeText(
                                      profilePageUsersRecord.ailments!,
                                      style: FlutterFlowTheme.of(context)
                                          .headlineSmall,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 12.0, 0.0, 12.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Column(
                                    mainAxisSize: MainAxisSize.max,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Next Appointment',
                                        textAlign: TextAlign.start,
                                        style: FlutterFlowTheme.of(context)
                                            .bodySmall,
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 4.0, 0.0, 0.0),
                                        child: Text(
                                          'Aug 20, 2021',
                                          style: FlutterFlowTheme.of(context)
                                              .displaySmall,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Divider(
                              height: 4.0,
                              thickness: 1.0,
                              color: FlutterFlowTheme.of(context)
                                  .primaryBackground,
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 1.0, 0.0, 0.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  if (!(Theme.of(context).brightness ==
                                      Brightness.dark))
                                    InkWell(
                                      onTap: () async {
                                        setDarkModeSetting(
                                            context, ThemeMode.dark);
                                        if (animationsMap[
                                                'containerOnActionTriggerAnimation2'] !=
                                            null) {
                                          setState(() =>
                                              hasContainerTriggered2 = true);
                                          SchedulerBinding.instance
                                              .addPostFrameCallback((_) async =>
                                                  await animationsMap[
                                                          'containerOnActionTriggerAnimation2']!
                                                      .controller
                                                      .forward(from: 0.0));
                                        }
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                1.0,
                                        decoration: BoxDecoration(),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 12.0, 24.0, 12.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                'Switch to Dark Mode',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium,
                                              ),
                                              Container(
                                                width: 80.0,
                                                height: 40.0,
                                                decoration: BoxDecoration(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryBackground,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20.0),
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.95, 0.0),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0.0,
                                                                    0.0,
                                                                    8.0,
                                                                    0.0),
                                                        child: Icon(
                                                          Icons.nights_stay,
                                                          color:
                                                              Color(0xFF95A1AC),
                                                          size: 20.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              -0.85, 0.0),
                                                      child: Container(
                                                        width: 36.0,
                                                        height: 36.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                          boxShadow: [
                                                            BoxShadow(
                                                              blurRadius: 4.0,
                                                              color: Color(
                                                                  0x430B0D0F),
                                                              offset: Offset(
                                                                  0.0, 2.0),
                                                            )
                                                          ],
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      30.0),
                                                          shape: BoxShape
                                                              .rectangle,
                                                        ),
                                                      ).animateOnActionTrigger(
                                                          animationsMap[
                                                              'containerOnActionTriggerAnimation1']!,
                                                          hasBeenTriggered:
                                                              hasContainerTriggered1),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (Theme.of(context).brightness ==
                                      Brightness.dark)
                                    InkWell(
                                      onTap: () async {
                                        setDarkModeSetting(
                                            context, ThemeMode.light);
                                        if (animationsMap[
                                                'containerOnActionTriggerAnimation1'] !=
                                            null) {
                                          setState(() =>
                                              hasContainerTriggered1 = true);
                                          SchedulerBinding.instance
                                              .addPostFrameCallback((_) async =>
                                                  await animationsMap[
                                                          'containerOnActionTriggerAnimation1']!
                                                      .controller
                                                      .forward(from: 0.0));
                                        }
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                1.0,
                                        decoration: BoxDecoration(),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0.0, 12.0, 24.0, 12.0),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(
                                                'Switch to Light Mode',
                                                style:
                                                    FlutterFlowTheme.of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily: 'Outfit',
                                                          color: Colors.white,
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.w500,
                                                        ),
                                              ),
                                              Container(
                                                width: 80.0,
                                                height: 40.0,
                                                decoration: BoxDecoration(
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryBackground,
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          20.0),
                                                ),
                                                child: Stack(
                                                  alignment:
                                                      AlignmentDirectional(
                                                          0.0, 0.0),
                                                  children: [
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              -0.9, 0.0),
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    8.0,
                                                                    2.0,
                                                                    0.0,
                                                                    0.0),
                                                        child: Icon(
                                                          Icons
                                                              .wb_sunny_rounded,
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryText,
                                                          size: 24.0,
                                                        ),
                                                      ),
                                                    ),
                                                    Align(
                                                      alignment:
                                                          AlignmentDirectional(
                                                              0.9, 0.0),
                                                      child: Container(
                                                        width: 36.0,
                                                        height: 36.0,
                                                        decoration:
                                                            BoxDecoration(
                                                          color: FlutterFlowTheme
                                                                  .of(context)
                                                              .secondaryBackground,
                                                          boxShadow: [
                                                            BoxShadow(
                                                              blurRadius: 4.0,
                                                              color: Color(
                                                                  0x430B0D0F),
                                                              offset: Offset(
                                                                  0.0, 2.0),
                                                            )
                                                          ],
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(
                                                                      30.0),
                                                          shape: BoxShape
                                                              .rectangle,
                                                        ),
                                                      ).animateOnActionTrigger(
                                                          animationsMap[
                                                              'containerOnActionTriggerAnimation2']!,
                                                          hasBeenTriggered:
                                                              hasContainerTriggered2),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          20.0, 12.0, 20.0, 12.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Text(
                            'Past Appointments',
                            style: FlutterFlowTheme.of(context).bodySmall,
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 24.0),
                      child: StreamBuilder<List<AppointmentsRecord>>(
                        stream: queryAppointmentsRecord(
                          queryBuilder: (appointmentsRecord) =>
                              appointmentsRecord
                                  .where('appointmentTime',
                                      isLessThan: getCurrentTimestamp)
                                  .where('appointmentPerson',
                                      isEqualTo: currentUserReference),
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 40.0,
                                height: 40.0,
                                child: SpinKitPumpingHeart(
                                  color: FlutterFlowTheme.of(context).primary,
                                  size: 40.0,
                                ),
                              ),
                            );
                          }
                          List<AppointmentsRecord>
                              listViewAppointmentsRecordList = snapshot.data!;
                          if (listViewAppointmentsRecordList.isEmpty) {
                            return Center(
                              child: EmptyListWidget(),
                            );
                          }
                          return ListView.builder(
                            padding: EdgeInsets.zero,
                            shrinkWrap: true,
                            scrollDirection: Axis.vertical,
                            itemCount: listViewAppointmentsRecordList.length,
                            itemBuilder: (context, listViewIndex) {
                              final listViewAppointmentsRecord =
                                  listViewAppointmentsRecordList[listViewIndex];
                              return Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 0.0, 0.0, 8.0),
                                child: StreamBuilder<List<AppointmentsRecord>>(
                                  stream: queryAppointmentsRecord(
                                    singleRecord: true,
                                  ),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 40.0,
                                          height: 40.0,
                                          child: SpinKitPumpingHeart(
                                            color: FlutterFlowTheme.of(context)
                                                .primary,
                                            size: 40.0,
                                          ),
                                        ),
                                      );
                                    }
                                    List<AppointmentsRecord>
                                        appointmentCardAppointmentsRecordList =
                                        snapshot.data!;
                                    // Return an empty Container when the item does not exist.
                                    if (snapshot.data!.isEmpty) {
                                      return Container();
                                    }
                                    final appointmentCardAppointmentsRecord =
                                        appointmentCardAppointmentsRecordList
                                                .isNotEmpty
                                            ? appointmentCardAppointmentsRecordList
                                                .first
                                            : null;
                                    return InkWell(
                                      onTap: () async {
                                        context.pushNamed(
                                          'appointmentDetailsProfile',
                                          queryParams: {
                                            'appointmentDetails':
                                                serializeParam(
                                              listViewAppointmentsRecord
                                                  .reference,
                                              ParamType.DocumentReference,
                                            ),
                                          }.withoutNulls,
                                        );
                                      },
                                      child: Container(
                                        width:
                                            MediaQuery.of(context).size.width *
                                                1.0,
                                        decoration: BoxDecoration(
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryBackground,
                                          boxShadow: [
                                            BoxShadow(
                                              blurRadius: 4.0,
                                              color: Color(0x230F1113),
                                              offset: Offset(0.0, 2.0),
                                            )
                                          ],
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                        ),
                                        child: Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  12.0, 12.0, 12.0, 12.0),
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Row(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Expanded(
                                                    child: Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  4.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        listViewAppointmentsRecord
                                                            .appointmentType!,
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .headlineSmall,
                                                      ),
                                                    ),
                                                  ),
                                                  Icon(
                                                    Icons.chevron_right_rounded,
                                                    color: FlutterFlowTheme.of(
                                                            context)
                                                        .grayLight,
                                                    size: 24.0,
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 8.0, 0.0, 0.0),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Card(
                                                      clipBehavior: Clip
                                                          .antiAliasWithSaveLayer,
                                                      color: FlutterFlowTheme
                                                              .of(context)
                                                          .primaryBackground,
                                                      shape:
                                                          RoundedRectangleBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20.0),
                                                      ),
                                                      child: Row(
                                                        mainAxisSize:
                                                            MainAxisSize.max,
                                                        children: [
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        8.0,
                                                                        4.0,
                                                                        8.0,
                                                                        4.0),
                                                            child: Text(
                                                              dateTimeFormat(
                                                                  'MMMEd',
                                                                  listViewAppointmentsRecord
                                                                      .appointmentTime!),
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodySmall,
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        0.0,
                                                                        0.0,
                                                                        8.0,
                                                                        0.0),
                                                            child: Text(
                                                              dateTimeFormat(
                                                                  'jm',
                                                                  listViewAppointmentsRecord
                                                                      .appointmentTime!),
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  8.0,
                                                                  0.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Text(
                                                        'For',
                                                        style:
                                                            FlutterFlowTheme.of(
                                                                    context)
                                                                .bodyMedium,
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    4.0,
                                                                    0.0,
                                                                    0.0,
                                                                    0.0),
                                                        child: Text(
                                                          listViewAppointmentsRecord
                                                              .appointmentName!,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Outfit',
                                                                color: FlutterFlowTheme.of(
                                                                        context)
                                                                    .secondary,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                ),
                              );
                            },
                          ).animateOnPageLoad(
                              animationsMap['listViewOnPageLoadAnimation']!);
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
